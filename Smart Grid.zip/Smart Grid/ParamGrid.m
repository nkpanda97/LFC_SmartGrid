%%
clc,
clear all,
close all,

%% Parameter Values for hydro power plant

Kp1 = 115;   % Hz/W
Kp4 = 80;    % Hz/W
Kp7 = 100;   % Hz/W

Kph = [Kp1 Kp4 Kp7]';

ch  = 12;    % Disturbance scaling factor

Tp1 = 20;    % sec
Tp4 = 13;    % sec
Tp7 = 15;    % sec

Tph = [Tp1 Tp4 Tp7]';

R1  = 2.5;   % Hz/W
R4  = 3.3;   % Hz/W
R7  = 3;     % Hz/W

Rh  = [R1 R4 R7]';

Tg1 = 0.1;   % sec
Tg4 = 0.08;  % sec
Tg7 = 0.17;  % sec

Tgh = [Tg1 Tg4 Tg7]';

Tr1 = 0.6;   % sec
Tr4 = 0.513; % sec
Tr7 = 0.5;   % sec

Trh = [Tr1 Tr4 Tr7]';

Tw1 = 1;     % sec
Tw4 = 2;     % sec
Tw7 = 0.5;   % sec

Twh = [Tw1 Tw4 Tw7]';

T11 = .7;    % sec
T14 = .1;    % sec
T17 = .2;    % sec

T1h = [T11 T14 T17]';

T21 = 5;     % sec
T24 = 10;    % sec
T27 = 7.5;   % sec

T2h = [T21 T24 T27]';

% Factors

a1 = Tr1/(T11*T21*R1);
a4 = Tr4/(T14*T24*R4);
a7 = Tr7/(T17*T27*R7);

ah = [a1 a4 a7]';

b1 = (Tr1 - T11)/(T11*T21);
b4 = (Tr4 - T14)/(T14*T24);
b7 = (Tr7 - T17)/(T17*T27);

bh = [b1 b4 b7];

k1 = (T21 + Tw1)/(T21*Tw1);
k4 = (T24 + Tw4)/(T24*Tw4);
k7 = (T27 + Tw7)/(T27*Tw7);

kh = [k1 k4 k7]';

%% Parameter Values for thermal power plant

Kp3 = 120; % Hz/W
Kp6 = 75;  % Hz/W

Kpt = [Kp3 Kp6]';

ct  = 1e5;  % Disturbance scaling factor

Tp3 = 20; % sec
Tp6 = 15; % sec

Tpt = [Tp3 Tp6]';

R3  = 2.4; % Hz/W
R6  = 3;   % Hz/W

Rt  = [R3 R6]';

Kr3 = 0.005; % W/Hz
Kr6 = 0.01;  % W/Hz

Krt = [Kr3 Kr6]';

Tg3 = 0.08;  % sec
Tg6 = 0.2;   % sec

Tgt = [Tg3 Tg6]';

Tt3 = 0.3;   % sec
Tt6 = 0.3;   % sec

Ttt = [Tt3 Tt6]';

Tr3 = 10;    % sec
Tr6 = 10;    % sec

Trt = [Tr3 Tr6]';

%% Parameter Values for wind power plant

% Wind turbine bladespan (radius)

Rw = 52; % m

% Moment of inertia (rotor)

Jr2 = 18.5;  % kg m^2
Jr5 = 20;    % kg m^2
Jr8 = 20;    % kg m^2
Jr9 = 21.5;  % kg m^2

Jrw = [Jr2 Jr5 Jr8 Jr9]';

% Moment of inertia (blades)

Jp2 = 2;   % kg m^2
Jp5 = 1.5; % kg m^2
Jp8 = 1.8; % kg m^2
Jp9 = 2.3; % kg m^2

Jpw = [Jp2 Jp5 Jp8 Jp9]';

Kp2 = 1;    % kg m/s
Kp5 = 1.2;  % kg m/s
Kp8 = 0.95; % kg m/s
Kp9 = 1.4;  % kg m/s

Kpw = [Kp2 Kp5 Kp8 Kp9]';

% Air flow factor 

brw  = 0.92;

% Angular momentum factor

pp2 = 1.2;  % kg m/s
pp5 = 1.5;  % kg m/s
pp8 = 0.88; % kg m/s
pp9 = 0.95; % kg m/s

ppw = [pp2 pp5 pp8 pp9]';

% Rotor angular velocity

wr2 = 270; % rad/s
wr5 = 268; % rad/s
wr8 = 273; % rad/s
wr9 = 272; % rad/s

wrw = [wr2 wr5 wr8 wr9]';

% Nominal air speed

vao = 8; % m/s

% Constant

cw  = -2;

%% Parameter values for interconnection

Ks1 = 0.545;
Ks3 = 0.5;
Ks4 = 0.444;
Ks6 = 0.505;
Ks7 = 0.679;

Ks  = [Ks1 Ks3 Ks4 Ks6 Ks7]';

