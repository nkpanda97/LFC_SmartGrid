tic
clear variables
clc
close all
boolt=1;boolw=1;boolh=1; % Case Selection for Disturbnace on and off
run("ParamGrid.m") % Loading of Parameters
timespan=0:0.1:200;% Simulation Time Setting
config=-1; % 1--> open loop -1---> Closed loop
%% *Modelling of Hydro Power Plant*

% Input and Disturbance for Hydro
u_hydro=ones(1,size(timespan,2));
di_hydro=150;
%% 
% 

for i=1:3
    A_hydro=[-2/Twh(i)             0                  2*kh(i)                  2*ah(i)         ;...
          0                    -1/T2h(i)              -bh(i)                  -ah(i)          ;...
          0                         0                -1/T1h(i)           -1/(T1h(i)*Rh(i)) ; ...
          Kph(i)/Tph(i)                0                  0                       -1/Tph(i)      ];
    B_hydro= [0       ;...
               0       ;...
               0       ;...
             Kph(i)/Tgh(i)  ];
    C_hydro=[1 0 0 0;...
             0 0 0 1];
     E_hydro=ch*Kph(i)/Tph(i);
     if i==1
         A.G1=A_hydro;
         B.G1=B_hydro;
         C.G1=C_hydro;
         di_G1=((1+E_hydro*di_hydro)).*u_hydro;
     end
     if i==2
         A.G4=A_hydro;
         B.G4=B_hydro;
         C.G4=C_hydro;
         di_G4=((1+E_hydro*di_hydro)).*u_hydro;
     end
     if i==3
         A.G7=A_hydro;
         B.G7=B_hydro;
         C.G7=C_hydro;
         di_G7=((1+E_hydro*di_hydro)).*u_hydro;
     end
     
end

%% Making of State Space models

sys_G1=ss(A.G1,B.G1,C.G1,0);
sys_G4=ss(A.G4,B.G4,C.G4,0);
sys_G7=ss(A.G7,B.G7,C.G7,0);
%% *Plot of open loop system*

y_G1=lsim(sys_G1,di_G1,timespan);
y_G4=lsim(sys_G4,di_G4,timespan);
y_G7=lsim(sys_G7,di_G7,timespan);

figure 
% Plotting of Delta Power
subplot(3,1,1)
plot(timespan,y_G1(:,1))
xlabel('time')
ylabel('\Delta P_{g1}')
subplot(3,1,2)
plot(timespan,y_G4(:,1))
xlabel('time')
ylabel('\Delta P_{g4}')
subplot(3,1,3)
plot(timespan,y_G7(:,1))
xlabel('time')
ylabel('\Delta P_{g7}')
sgtitle('Open loop response of Power Deviation for G1,G4 & G7')
%Plotting the Delta Frequency
figure
subplot(3,1,1)
plot(timespan,y_G1(:,2))
xlabel('time')
ylabel('\Delta f1')
subplot(3,1,2)
plot(timespan,y_G4(:,2))
xlabel('time')
ylabel('\Delta f4')
subplot(3,1,3)
plot(timespan,y_G7(:,2))
xlabel('time')
ylabel('\Delta f7')
sgtitle('Open loop response of Frequency Deviation for G1,G4 & G7')
%% Disturbance Augmented Model
% 


% For G1
sys_l_G1=ss([sys_G1.A sys_G1.B;zeros(1,5)],[sys_G1.B;0],[sys_G1.C,[0;0]],0);
A_l_G1=double(sys_l_G1.A);
B_l_G1=double(sys_l_G1.B);
C_l_G1=double(sys_l_G1.C);
D_l_G1=double(sys_l_G1.D);

%For G4
sys_l_G4=ss([sys_G4.A sys_G4.B;zeros(1,5)],[sys_G4.B;0],[sys_G4.C,[0;0]],0);
A_l_G4=double(sys_l_G4.A);
B_l_G4=double(sys_l_G4.B);
C_l_G4=double(sys_l_G4.C);
D_l_G4=double(sys_l_G4.D);

%For G7
sys_l_G7=ss([sys_G7.A sys_G7.B; zeros(1,5)],[sys_G7.B;0],[sys_G7.C,[0;0]],0);
A_l_G7=double(sys_l_G7.A);
B_l_G7=double(sys_l_G7.B);
C_l_G7=double(sys_l_G7.C);
D_l_G7=double(sys_l_G7.D);
%% LQR Control Design

% LQR for G1
Q_G1_control=10^10*eye(4);
R_G1_control=eye(1);
[Klqr_G1 ,~, Poles_G1_Controller]=lqr(sys_G1,Q_G1_control,R_G1_control);
K_G1_simulation=[Klqr_G1,-100,Klqr_G1,-100]; % Only used for LSIm simulation ( Simulating the [X;X^] model

% LQR for G4
Q_G4_control=10^10*eye(4);
R_G4_control=eye(1);
[Klqr_G4 ,~, Poles_G4_Controller]=lqr(sys_G4,Q_G4_control,R_G4_control);
K_G4_simulation=[Klqr_G4,-100,Klqr_G4,-100]; % Only used for LSIm simulation ( Simulating the [X;X^] model

% LQR for G7
Q_G7_control=10^10*eye(4);
R_G7_control=eye(1);
[Klqr_G7 ,~, Poles_G7_Controller]=lqr(sys_G7,Q_G7_control,R_G7_control);
K_G7_simulation=[Klqr_G7,-100,Klqr_G7,-100]; % Only used for LSIm simulation ( Simulating the [X;X^] model
%% Observer Design for disturbance

% For G1
[L_G1,~,Poles_G1_Observer]=(lqr(sys_l_G1.A',sys_l_G1.C',20^10.*eye(5),1));
l_G1=L_G1';

% For G4
[L_G4,~,Poles_G4_Observer]=(lqr(sys_l_G4.A',sys_l_G4.C',20^10.*eye(5),1));
l_G4=L_G4';


% For G7
[L_G7,~,Poles_G7_Observer]=(lqr(sys_l_G7.A',sys_l_G7.C',20^10.*eye(5),1));
l_G7=L_G7';


%Display of the Controller Poles and Observer Poles

table( [Poles_G1_Controller;0],Poles_G1_Observer,[Poles_G4_Controller;0],...
    Poles_G4_Observer,...
    [Poles_G7_Controller;0],Poles_G7_Observer)
%% Lumping of the Observer Model
% 

C_obs=[ 1 0 0 0 0 0 0 0 0 0;...
        0 0 0 1 0 0 0 0 0 0;...
        0 0 0 0 0 1 0 0 0 0;...
        0 0 0 0 0 0 0 0 1 0;];
     
sys_obs_G1=ss([sys_l_G1.A zeros(5,5);l_G1*sys_l_G1.C (sys_l_G1.A-l_G1*sys_l_G1.C)],...
    [sys_l_G1.B;sys_l_G1.B],C_obs,0);


sys_obs_G4=ss([sys_l_G4.A zeros(5,5);l_G4*sys_l_G4.C (sys_l_G4.A-l_G4*sys_l_G4.C)],...
    [sys_l_G4.B;sys_l_G4.B],C_obs,0);

sys_obs_G7=ss([sys_l_G7.A zeros(5,5);l_G7*sys_l_G7.C (sys_l_G7.A-l_G7*sys_l_G7.C)],...
    [sys_l_G7.B;sys_l_G7.B],C_obs,0);

%% Plotting of The observer Design

Y_obs_G1=lsim(sys_obs_G1,di_G1,timespan,[1390 0 0 0 0 0 0 0 1500 0 ]);

Y_obs_G4=lsim(sys_obs_G4,di_G4,timespan,[1390 0 0 0 0 0 0 0 1500 0 ]);

Y_obs_G7=lsim(sys_obs_G7,di_G7,timespan,[1390 0 0 0 0 0 0 0 1500 0 ]);


figure
subplot(3,1,1)
plot(timespan,Y_obs_G1(:,1))
hold on
plot(timespan,Y_obs_G1(:,3))
%axis([0 200 -4000 3000])
title('\Delta P_{g1}')
legend('X1' ,'\^X2')
grid
subplot(3,1,2)
plot(timespan,Y_obs_G4(:,1))
hold on
plot(timespan,Y_obs_G4(:,3))
%axis([0 200 -4000 3000])
title('\Delta P_{g4}')
legend('X1' ,'\^X2')
grid
subplot(3,1,3)
plot(timespan,Y_obs_G7(:,1))
hold on
plot(timespan,Y_obs_G7(:,3))
%axis([0 200 -4000 3000])
title('\Delta P_{g7}')
legend('X1' ,'\^X2')
sgtitle('Observer Output of Power Deviation for Hydro Plant')
grid


figure
subplot(3,1,1)
plot(timespan,Y_obs_G1(:,2))
hold on
plot(timespan,Y_obs_G1(:,4))
%axis([0 200 -4000 3000])
title('\Delta f_1')
legend('X1' ,'\^X2')
grid
subplot(3,1,2)
plot(timespan,Y_obs_G4(:,2))
hold on
plot(timespan,Y_obs_G4(:,4))
%axis([0 200 -4000 3000])
title('\Delta f_4')
legend('X1' ,'\^X2')
grid
subplot(3,1,3)
plot(timespan,Y_obs_G7(:,2))
hold on
plot(timespan,Y_obs_G7(:,4))
%axis([0 200 -4000 3000])
title('\Delta f_7')
legend('X1' ,'\^X2')
sgtitle('Observer Output of Frequency Deviation for Hydro Plant')
grid

A_new_h=sys_obs_G1.A-sys_obs_G1.B*[Klqr_G1 0 Klqr_G1 0];
sys_G1_cls=ss(A_new_h,sys_obs_G1.B,sys_obs_G1.C,0);
y_cls_G1=lsim(sys_G1_cls,di_G1,timespan);

figure
subplot(2,1,1)
plot(timespan,y_cls_G1(:,1))
title('Output-1 of Hydro G1')
xlabel('Time')
ylabel('\Delta P_g')
grid
subplot(2,1,2)
plot(timespan,y_cls_G1(:,2))
title('Output-2 of Hydro G1')
xlabel('Time')
ylabel('\Delta f')
sgtitle('Closed Loop Response')
grid
A_new_h=sys_obs_G4.A-sys_obs_G4.B*[Klqr_G4 0 Klqr_G4 0];
sys_G4_cls=ss(A_new_h,sys_obs_G4.B,sys_obs_G4.C,0);
y_cls_G4=lsim(sys_G4_cls,di_G4,timespan);

figure
subplot(2,1,1)
plot(timespan,y_cls_G4(:,1))
title('Output-1 of Hydro G4')
xlabel('Time')
ylabel('\Delta P_g')
grid
subplot(2,1,2)
plot(timespan,y_cls_G4(:,2))
title('Output-2 of Hydro G4')
xlabel('Time')
ylabel('\Delta f')
sgtitle('Closed Loop Response')
grid
% For G7
Q=1000*eye(4);
R=0.01*eye(1);
[Klqr_G1 ,P, S]=lqr(sys_G7,Q,R);
K=[Klqr_G1,-100,Klqr_G1,-100];


A_new_h=sys_obs_G7.A-sys_obs_G7.B*[Klqr_G7 0 Klqr_G7 0];
sys_G7_cls=ss(A_new_h,sys_obs_G7.B,sys_obs_G7.C,0);
y_cls_G7=lsim(sys_G7_cls,di_G7,timespan);

figure
subplot(2,1,1)
plot(timespan,y_cls_G7(:,1))
title('Output-1 of Hydro G7')
xlabel('Time')
ylabel('\Delta P_g')
grid
subplot(2,1,2)
plot(timespan,y_cls_G7(:,2))
title('Output-2 of Hydro G7')
xlabel('Time')
ylabel('\Delta f')
sgtitle('Closed Loop Response')
grid

%% Design of Disturbance Rejection Gain
% 

% G1-----------
% Here S=0 Hence The solution of Pi and Gamma are simple
E.G1=[0;0;0;69];
E.G4=[0;0;0 ;73];
E.G7=[0;0;0;80];
M_G1=[A.G1 B.G1;C.G1 [ 0 ; 0]];
new1=[E.G1;zeros(2,1)];
new2=M_G1\new1;
Pi_G1=new2(1:4);
Ga_G1=new2(5,:);
G_G1=Ga_G1+Klqr_G1*Pi_G1;


% G4-----------
% Here S=0 Hence The solution of Pi and Gamma are simple
E.G4=[0;0;0;69];
E.G4=[0;0;0 ;73];
E.G7=[0;0;0;80];
M_G4=[A.G4 B.G4;C.G4 [ 0 ; 0]];
new1=[E.G4;zeros(2,1)];
new2=M_G4\new1;
Pi_G4=new2(1:4);
Ga_G4=new2(5,:);
G_G4=Ga_G4+Klqr_G4*Pi_G4;


% G7-----------
% Here S=0 Hence The solution of Pi and Gamma are simple
E.G7=[0;0;0;69];
E.G4=[0;0;0 ;73];
E.G7=[0;0;0;80];
M_G7=[A.G7 B.G7;C.G7 [ 0 ; 0]];
new1=[E.G7;zeros(2,1)];
new2=M_G7\new1;
Pi_G7=new2(1:4);
Ga_G7=new2(5,:);
G_G7=Ga_G7+Klqr_G7*Pi_G7;


%%%% The above Gain can be used diectly as a feed forward loop. But as I am
%%%% estimating the disturbance already we will take all gains as 1;
G_G1=1;G_G4=1;G_G7=1;


%% *Modelling of wind turbines*
% 

% Input Parameters to Wind
var_input=0.001;%Process Noise
var_output=0.2;% MEassurement Noise
input_di=sqrt(var_input).*randn(1,size(timespan,2));
output_di=sqrt(var_output).*randn(1,size(timespan,2));
u_wind=[ones(2, length(timespan));input_di];
%% *Lineariziation of given model*

%% Defining of Sym Varialbles

syms omega_ri theta_pi omega_pi tau_cri tau_pri v_ai;
X_wind=[omega_ri; theta_pi; omega_pi];% State Variables
U_wind=[tau_cri; tau_pri; v_ai] ;% Input variables
Eq_points=zeros(4,3); % Matrix of equilibrium points
for i= 1:4 % G2 G5 G8 G9 wind turbines
    % For the A matrix
    lambda=Rw*omega_ri/v_ai; C_p=exp(-1/lambda)*(1.1-0.2*theta_pi);
    eq1=(brw*v_ai^3*C_p/omega_ri-tau_cri)/Jrw(i);
    eq2=omega_pi;
    eq3=(ppw(i)*v_ai^2*cos(theta_pi)-Kpw(i)*omega_pi+tau_pri)/Jpw(i);
    nl_eq_B=[eq1;eq2;eq3]; % Formation od system of ode for B Matrix
    nl_eq_A=[eq1;eq2;eq3]; % Formation od system of ode for A Matrix
    

% Finding of equillibrium points 

    nl_eq_A_subs=subs(nl_eq_A,[omega_ri,tau_pri,v_ai],[wrw(i),-10,vao]);% Substituting the given values first
 
% Solving by equating to 0 for w_pi, theta_pi, tau_cri
 
%                 [tau_cr2;  theta_p2 ;  omega_p2]
%       Eq_points=[tau_cr5;  theta_p5 ;  omega_p5]  
%                 [tau_cr8;  theta_p8 ;  omega_p8]
%                 [tau_cr9;  theta_p9 ;  omega_p9]
    dummy_1=struct2array(solve(nl_eq_A_subs==0,[tau_cri; theta_pi ;omega_pi]));
    double(dummy_1);
    Eq_points(i,:)=dummy_1(2,:);
 % Getting the quilibrium points
    
    
 % Getting the A matrices
    Jaco_A=subs(jacobian(nl_eq_A,X_wind),[omega_ri theta_pi omega_pi tau_cri tau_pri v_ai],...
        [wrw(i),Eq_points(i,2), Eq_points(i,3), Eq_points(i,1), -10, vao]);
 % B Matrix
    Jaco_B=subs(jacobian(nl_eq_B,U_wind),[omega_ri theta_pi omega_pi tau_cri tau_pri v_ai],...
        [wrw(i),Eq_points(i,2), Eq_points(i,3), Eq_points(i,1), -10, vao]);
    
 % State Space Representation
%     X'= AX+BU+EV;
%     Y=CX+ V
    if i==1
        A.G2=Jaco_A;
        B.G2=Jaco_B(:,1:2);
        B_di.G2=Jaco_B;
        E.G2=Jaco_B(:,3);
        C.G2=[cw 0 0;...
               0 1 0;...
               1 0 0];
    end
    if i==2
        A.G5=Jaco_A;
        B.G5=Jaco_B(:,1:2);
          B_di.G5=Jaco_B;
        E.G5=Jaco_B(:,3);
        C.G5=[cw 0 0;...
               0 1 0;...
               1 0 0];
    end
    if i==3
        A.G8=Jaco_A;
        B.G8=Jaco_B(:,1:2);
          B_di.G8=Jaco_B;
        E.G81=Jaco_B(:,3);
        C.G8=[cw 0 0;...
               0 1 0;...
               1 0 0];
    end
    if i==4
        A.G9=Jaco_A;
        B.G9=Jaco_B(:,1:2);
          B_di.G9=Jaco_B;
        E.G9=Jaco_B(:,3);
        C.G9=[cw 0 0;...
               0 1 0;...
               1 0 0];
    end   
end
%% Plotting of Wind model 

sys_G2=ss(double(A.G2),double(B_di.G2),double(C.G2),0);
sys_G5=ss(double(A.G5),double(B_di.G5),double(C.G5),0);
sys_G8=ss(double(A.G8),double(B_di.G8),double(C.G8),0);
sys_G9=ss(double(A.G9),double(B_di.G9),double(C.G9),0);

Y_G2=lsim(sys_G2,u_wind,timespan)+[output_di' output_di' output_di' ]+[input_di' input_di' input_di' ];
Y_G5=lsim(sys_G5,u_wind,timespan)+[output_di' output_di' output_di']+[input_di' input_di' input_di' ];
Y_G8=lsim(sys_G8,u_wind,timespan)+[output_di' output_di' output_di']+[input_di' input_di' input_di' ];
Y_G9=lsim(sys_G9,u_wind,timespan)+[output_di' output_di' output_di']+[input_di' input_di' input_di' ];
%Y_G2,5,8,9(:,1)----> ΔPgi  Y_G2,5,8,9(:,2)----> ΔTheta_pi  Y_G2,5,8,9(:,3)----> ΔOmega_ri


figure
subplot(3,1,1)
plot(timespan,Y_G2(:,1))
xlabel('Time (sec)')
ylabel('\Delta P_{g2}')
grid
subplot(3,1,2)
plot(timespan,Y_G2(:,2))
xlabel('Time (sec)')
ylabel('\Delta \theta_{p2}')
grid
subplot(3,1,3)
plot(timespan,Y_G2(:,3))
xlabel('Time (sec)')
ylabel('\Delta \omega_{r2}')
grid
sgtitle('Output for Wind Power Plant- G2')
figure
subplot(3,1,1)
plot(timespan,Y_G5(:,1))
xlabel('Time (sec)')
ylabel('\Delta P_{g5}')
grid
subplot(3,1,2)
plot(timespan,Y_G5(:,2))
xlabel('Time (sec)')
ylabel('\Delta \theta_{p5}')
grid
subplot(3,1,3)
plot(timespan,Y_G5(:,3))
xlabel('Time (sec)')
ylabel('\Delta \omega_{r5}')
grid
sgtitle('Output for Wind Power Plant- G5')

figure
subplot(3,1,1)
plot(timespan,Y_G8(:,1))
xlabel('Time (sec)')
ylabel('\Delta P_{g8}')
grid
subplot(3,1,2)
plot(timespan,Y_G8(:,2))
xlabel('Time (sec)')
ylabel('\Delta \theta_{p8}')
grid
subplot(3,1,3)
plot(timespan,Y_G8(:,3))
xlabel('Time (sec)')
ylabel('\Delta \omega_{r8}')
grid
sgtitle('Output for Wind Power Plant- G8')

figure
subplot(3,1,1)
plot(timespan,Y_G9(:,1))
xlabel('Time (sec)')
ylabel('\Delta P_{g9}')
grid
subplot(3,1,2)
plot(timespan,Y_G9(:,2))
xlabel('Time (sec)')
ylabel('\Delta \theta_{p9}')
grid
subplot(3,1,3)
plot(timespan,Y_G9(:,3))
xlabel('Time (sec)')
ylabel('\Delta \omega_{r2}')
grid
sgtitle('Output for Wind Power Plant- G9')
%% KALMAN Filter Design


Q=(double(B_di.G2(:,3)))*0.001*(double(B_di.G2(:,3)))';
R=0.2*eye(3);

% For G2
L_Kalman_G2=(lqr(double(sys_G2.A)',double(sys_G2.C)',Q,R));
A_G2_est=[double(sys_G2.A) zeros(3,3);L_Kalman_G2*double(sys_G2.C)  double(sys_G2.A)-L_Kalman_G2*double(sys_G2.C) ];
sys_G2_estimated=ss(A_G2_est,[double(sys_G2.B);double(sys_G2.B)],[sys_G2.C zeros(3,3);zeros(3,3) sys_G2.C],0);
Y_est_G2=lsim(sys_G2_estimated,u_wind,timespan)+[output_di' output_di' output_di' zeros(2001,3) ];
% For G5
L_Kalman_G5=(lqr(double(sys_G5.A)',double(sys_G5.C)',Q,R));
A_G5_est=[double(sys_G5.A) zeros(3,3);L_Kalman_G5*double(sys_G5.C)  double(sys_G5.A)-L_Kalman_G2*double(sys_G5.C) ];
sys_G5_estimated=ss(A_G5_est,[double(sys_G5.B);double(sys_G5.B)],[sys_G5.C zeros(3,3);zeros(3,3) sys_G5.C],0);
Y_est_G5=lsim(sys_G5_estimated,u_wind,timespan)+[output_di' output_di' output_di' zeros(2001,3) ];
% For G8
L_Kalman_G8=(lqr(double(sys_G8.A)',double(sys_G8.C)',Q,R));
A_G8_est=[double(sys_G8.A) zeros(3,3);L_Kalman_G8*double(sys_G8.C)  double(sys_G8.A)-L_Kalman_G8*double(sys_G8.C) ];
sys_G8_estimated=ss(A_G8_est,[double(sys_G8.B);double(sys_G8.B)],[sys_G8.C zeros(3,3);zeros(3,3) sys_G8.C],0);
Y_est_G8=lsim(sys_G8_estimated,u_wind,timespan)+[output_di' output_di' output_di' zeros(2001,3) ];
% For G9
L_Kalman_G9=(lqr(double(sys_G9.A)',double(sys_G9.C)',Q,R));
A_G9_est=[double(sys_G9.A) zeros(3,3);L_Kalman_G8*double(sys_G9.C)  double(sys_G9.A)-L_Kalman_G8*double(sys_G9.C) ];
sys_G9_estimated=ss(A_G8_est,[double(sys_G8.B);double(sys_G9.B)],[sys_G9.C zeros(3,3);zeros(3,3) sys_G9.C],0);
Y_est_G9=lsim(sys_G9_estimated,u_wind,timespan)+[output_di' output_di' output_di' zeros(2001,3) ];

%% Plotting of Optimal State Estimator



figure
subplot(4,3,1)
plot(timespan,Y_est_G2(:,1));
hold on
plot(timespan,Y_est_G2(:,4),'LineWidth',2)
xlabel('Time')
ylabel('\Delta P_{G2}')
%legend('Orginal','Estimated')

subplot(4,3,2)
plot(timespan,Y_est_G2(:,2));
hold on
plot(timespan,Y_est_G2(:,5),'LineWidth',2)
xlabel('Time')
ylabel('\Delta \theta_{p2}')
%legend('Orginal','Estimated')

subplot(4,3,3)
plot(timespan,Y_est_G2(:,3));
hold on
plot(timespan,Y_est_G2(:,6),'LineWidth',2)
xlabel('Time')
ylabel('\Delta \omega_{r2}')
%legend('Orginal','Estimated')
%sgtitle('Estimated and Original Output for G2')
%For G5

subplot(4,3,4)
plot(timespan,Y_est_G5(:,1));
hold on
plot(timespan,Y_est_G5(:,4),'LineWidth',2)
xlabel('Time')
ylabel('\Delta P_{G5}')
%legend('Orginal','Estimated')

subplot(4,3,5)
plot(timespan,Y_est_G5(:,2));
hold on
plot(timespan,Y_est_G5(:,5),'LineWidth',2)
xlabel('Time')
ylabel('\Delta \theta_{p5}')
%legend('Orginal','Estimated')

subplot(4,3,6)
plot(timespan,Y_est_G5(:,3));
hold on
plot(timespan,Y_est_G5(:,6),'LineWidth',2)
xlabel('Time')
ylabel('\Delta \omega_{r5}')
%legend('Orginal','Estimated')
%sgtitle('Estimated and Original Output for G5')
%For G8

subplot(4,3,7)
plot(timespan,Y_est_G8(:,1));
hold on
plot(timespan,Y_est_G8(:,4),'LineWidth',2)
xlabel('Time')
ylabel('\Delta P_{G8}')
%legend('Orginal','Estimated')

subplot(4,3,8)
plot(timespan,Y_est_G8(:,2));
hold on
plot(timespan,Y_est_G8(:,5),'LineWidth',2)
xlabel('Time')
ylabel('\Delta \theta_{p8}')
%legend('Orginal','Estimated')

subplot(4,3,9)
plot(timespan,Y_est_G8(:,3));
hold on
plot(timespan,Y_est_G8(:,6),'LineWidth',2)
xlabel('Time')
ylabel('\Delta \omega_{r8}')
%legend('Orginal','Estimated')
%sgtitle('Estimated and Original Output for G8')

%For G9

subplot(4,3,10)
plot(timespan,Y_est_G9(:,1));
hold on
plot(timespan,Y_est_G9(:,4),'LineWidth',2)
xlabel('Time')
ylabel('\Delta P_{G9}')
%legend('Orginal','Estimated')
%
subplot(4,3,11)
plot(timespan,Y_est_G9(:,2));
hold on
plot(timespan,Y_est_G9(:,5),'LineWidth',2)
xlabel('Time')
ylabel('\Delta \theta_{p9}')
%legend('Orginal','Estimated')
%
subplot(4,3,12)
plot(timespan,Y_est_G9(:,3));
hold on
plot(timespan,Y_est_G9(:,6),'LineWidth',2)
xlabel('Time')
ylabel('\Delta \omega_{r9}')
%legend('Orginal','Estimated')
%sgtitle('Estimated and Original Output for G9')

%% *Modelling of Thermal Power Plant*
% 

thermalDisturbance='yes';

f_th=2; % \frequency of 2 Hz
w=2*pi*f_th;
% dX/dt= AX + B(u+600000*d/1500); Y=CX

for i=1:2
    A_thermal=[-1/Ttt(i)                   0               1/Ttt(i)                      0           ;...
          0                    -1/Tgt(i)                0                    -1/(Tgt(i)*Rt(i))  ;...
          0               1/Trt(i)-Krt(i)/Tgt(i)     -1/Trt(i)           -Krt(i)/(Tgt(i)*Rt(i))  ; ...
          Kpt(i)/Tpt(i)                0                  0                       -1/Tpt(i)      ];
    B_thermal=[0       ;...
               0       ;...
               0       ;...
             Kpt(i)/Tgt(i) ];
    C_thermal=[1 0 0 0;...
               0 0 0 1];
    E_thermal=[zeros(3,2);ct*Kpt(i)/Tpt(i)*[1 1]];
     if i==1
         A.G3=A_thermal;
         C.G3=C_thermal;
         E.G3=E_thermal;
         B.G3=B_thermal;
     else
         A.G6=A_thermal;
         C.G6=C_thermal;
         E.G6=E_thermal;
         B.G6=B_thermal;
     end
     
end

% State Space model
sys_G3=ss(A.G3,B.G3,C.G3,0);
sys_G6=ss(A.G6,B.G6,C.G6,0);
%% 
% *Plotting of Output-1 (Thermal)*

switch(thermalDisturbance)
    case 'yes'
        a_di_th=600000/1500;
    case 'no'
        a_di_th=0;
end
 u_thermal=ones(1,size(timespan,2))+ a_di_th.*(sin(w.*timespan+pi)...
     +sin(w.*timespan+pi)); % Input signal for thermal power plant
 
[Y_G3,t_G3,X_G3]=lsim(sys_G3,u_thermal,timespan);
[Y_G6,~,X_G6]=lsim(sys_G6,u_thermal,timespan);

figure(1)
subplot(2,1,1)
plot(t_G3,Y_G3(:,1))
hold on
plot(t_G3,Y_G6(:,1))
%axis([0 200 -4000 3000])
title('\Delta P_{gi}')
legend('G3' ,'G6')
grid

subplot(2,1,2)
plot(t_G3,Y_G3(:,2))
hold on
plot(t_G3,Y_G6(:,2))
%axis([0 200 -1.5*10^5 1.5*10^5])
title('\Delta f_{gi}')
legend('G3' ,'G6')
grid
sgtitle('Open Loop Outputs of the Thermal Power Plants')
%% 
% *Augmenting the disturbance*

% Disturbance Dynamics

A_di_th=[0 w;-w 0];
C_di_th=[1 0;0 1];
B_di_th=[0;0];
D_di_th=[0;0];
[num_di, den_di]=ss2tf(A_di_th,B_di_th,C_di_th,D_di_th); % SS->TF for the disturbance
Tf_di=tf(1,den_di)
[num_G3, den_G3]=ss2tf(A.G3,B.G3,C.G3,double(sys_G3.D))
Tf_G3=tf(num_G3(1,:),den_G3)
di_regection_G3_1=-Tf_di/Tf_G3;
% Augmenting the Dynamics (G3)
A_l_G3=[A.G3 E.G3; zeros(2,4) A_di_th];
B_l_G3=[B.G3;0;0];
C_l_G3=[C.G3 zeros(2,2)];
sys_l_G3=ss(A_l_G3,B_l_G3,C_l_G3,0);

% Augmenting the Dynamics (G6)
A_l_G6=[A.G6 E.G3; zeros(2,4) A_di_th];
B_l_G6=[B.G6;0;0];
C_l_G6=[C.G6 zeros(2,2)];
sys_l_G6=ss(A_l_G6,B_l_G6,C_l_G6,0);

[Y_l_G3,~,X_l_G3]=lsim(sys_l_G3,u_thermal,timespan);
[Y_l_G6,~,X_l_G6]=lsim(sys_l_G6,u_thermal,timespan);

figure(2)
subplot(2,1,1)
plot(t_G3,Y_l_G3(:,1))
hold on
plot(t_G3,Y_l_G6(:,1))
%axis([0 200 -4000 3000])
title('\Delta P_{gi}')
legend('G3' ,'G6')
grid

subplot(2,1,2)
plot(t_G3,Y_l_G3(:,2))
hold on
plot(t_G3,Y_l_G6(:,2))
%axis([0 200 -1.5*10^5 1.5*10^5])
title('\Delta f_{gi}')
legend('G3' ,'G6')
grid
sgtitle('Open Loop Outputs of the augmented Thermal Power Plants')
%% LQR Control Design

% LQR for111 G3
Q_G3_control=10000.*diag([1 1 1 1]);
R_G3_control=.1*eye(1);
[Klqr_G3 ,~, Poles_G3_Controller]=lqr(sys_G3,Q_G3_control,R_G3_control);
K_G3_simulation=[Klqr_G3,-100,Klqr_G3,-100]; % Only used for LSIm simulation ( Simulating the [X;X^] model

% LQR for G6
Q_G6_control=diag([10 1 1 90000 ]);
R_G6_control=eye(1);
[Klqr_G6 ,~, Poles_G6_Controller]=lqr(sys_G6,Q_G6_control,R_G6_control);
K_G4_simulation=[Klqr_G6,-100,Klqr_G6,-100]; % Only used for LSIm simulation ( Simulating the [X;X^] model
%% Disturbance Rejection Gain
% 

% % For G3
%Solving the Regulator Equation
%solve regulator equation with Kronecker calculus

M_G3=[A.G3 B.G3;C.G3 [ 0 ; 0]];
n_G3=length(A.G3);
n1_G3=size(M_G3,1)-n_G3;
n2_G3=size(M_G3,2)-n_G3;
As_G3=kron(eye(2),M_G3);
As_G3=As_G3-kron(A_di_th',[eye(n_G3) zeros(n_G3,n2_G3);zeros(n1_G3,n_G3) zeros(n1_G3,n2_G3)]);

bs_G3=-reshape([E.G3;[0 0;0  0]],12,1);%bs_G3=[bs_G3;bs_G3];
x=As_G3\bs_G3;
X=reshape(x,5,2);
Pi_G3=X(1:4,:);
Ga_G3=X(5,:);
%check whether indeed satisfied:
disp(M_G3*[Pi_G3;Ga_G3]-[Pi_G3;zeros(2,2)]*A_di_th+[E.G3;[0 0;0 0]]); %% As it is zero, hence Solvable
disp('Regulator Equation for G3 Solvable')
G_G3=Ga_G3+Klqr_G3*Pi_G3;


% % For G6
%Solving the Regulator Equation
%solve regulator equation with Kronecker calculus

M_G6=[A.G6 B.G6;C.G6 [ 0 ; 0]];
n_G6=length(A.G6);
n1_G6=size(M_G6,1)-n_G6;
n2_G6=size(M_G6,2)-n_G6;
As_G6=kron(eye(2),M_G6);
As_G6=As_G6-kron(A_di_th',[eye(n_G6) zeros(n_G6,n2_G6);zeros(n1_G6,n_G6) zeros(n1_G6,n2_G6)]);

bs_G6=-reshape([E.G6;[0 0;0  0]],12,1);%bs_G6=[bs_G6;bs_G6];
x=As_G6\bs_G6;
X=reshape(x,5,2);
Pi_G6=X(1:4,:);
Ga_G6=X(5,:);
%check whether indeed satisfied:
disp(M_G6*[Pi_G6;Ga_G6]-[Pi_G6;zeros(2,2)]*A_di_th+[E.G6;[0 0;0 0]]); %% As it is zero, hence Solvable
disp('Regulator Equation for G6 Solvable')
G_G6=Ga_G6+Klqr_G6*Pi_G6
%% Observer Design for disturbance

%For G3
Q_obs_thermal=10^3*eye(6);
[L_G3,~,Poles_G3_Observer]=(lqr(sys_l_G3.A',sys_l_G3.C',Q_obs_thermal,1));
l_G3=L_G3';
%l_G3=[(place(A.G3',C.G3',10*Poles_G3_Controller))';-100 -100;-100 -100];

% For G6
[L_G6,~,Poles_G6_Observer]=(lqr(sys_l_G6.A',sys_l_G6.C',20^10.*eye(6),1));
l_G6=L_G6';

%Display of the Controller Poles and Observer Poles

table([Poles_G3_Controller;0;0],Poles_G3_Observer,[Poles_G6_Controller;0;0],Poles_G6_Observer)
%% Lumping of the Observer Model
% 

C_obs=[ 1 0 0 0 0 0 0 0 0 0 0 0;...
        0 0 0 1 0 0 0 0 0 0 0 0;...
        0 0 0 0 0 0 1 0 0 0 0 0;...
        0 0 0 0 0 0 0 0 0 1 0 0;];
     
sys_obs_G3=ss([sys_l_G3.A zeros(6,6);l_G3*sys_l_G3.C (sys_l_G3.A-l_G3*sys_l_G3.C)],...
    [sys_l_G3.B;sys_l_G3.B],C_obs,0);


sys_obs_G6=ss([sys_l_G6.A zeros(6,6);l_G6*sys_l_G6.C (sys_l_G6.A-l_G6*sys_l_G6.C)],...
    [sys_l_G6.B;sys_l_G6.B],C_obs,0);


%% Plotting of The observer Design

Y_obs_G3=lsim(sys_obs_G3,u_thermal,timespan,[-1000 -2343 2342 123 0 0 0 0 0 0 0 0]);

Y_obs_G6=lsim(sys_obs_G6,u_thermal,timespan,[-1000 -2343 2342 123 0 0 0 0 0 0 0 0]);


figure
subplot(2,2,1)
plot(timespan,Y_obs_G3(:,2),'r')
hold on
%axis([0 200 -4000 3000])
ylabel('\Delta f_3 (Hz)')
xlabel('Time (sec)')
legend('actual')
grid
subplot(2,2,3)
plot(timespan,Y_obs_G3(:,4),'b')
%axis([0 200 -4000 3000])
legend('estimated')
ylabel('\Delta f_3 (Hz)')
xlabel('Time (sec)')

grid


subplot(2,2,2)
plot(timespan,Y_obs_G3(:,1),'r')
%axis([0 200 -4000 3000])
ylabel('\Delta P_{g3}')
xlabel('Time (sec)')
legend('actual')
grid
subplot(2,2,4)
plot(timespan,Y_obs_G3(:,3),'b')
ylabel('\Delta P_{g3}')
xlabel('Time (sec)')
title('\Delta P_{g6}')
legend('estimated')

sgtitle('Open Loop Observer Output of G3')
%% 

A_new_h=sys_obs_G3.A-sys_obs_G3.B*[Klqr_G3 0 0 Klqr_G3 0 0];
sys_G3_cls=ss(A_new_h,sys_obs_G3.B,sys_obs_G3.C,0);
y_cls_G3=lsim(sys_G3_cls,u_thermal,timespan);

figure
subplot(2,1,1)
plot(timespan,y_cls_G3(:,1))
title('Output-1 of Thermal G3')
xlabel('Time')
ylabel('\Delta P_g')
grid
subplot(2,1,2)
plot(timespan,y_cls_G3(:,2))
title('Output-2 of Hydro G3')
xlabel('Time')
ylabel('\Delta f')
sgtitle('Closed Loop Response')
grid
A_new_h=sys_obs_G6.A-sys_obs_G6.B*[Klqr_G6 0 0 Klqr_G6 0 0];
sys_G4_cls=ss(A_new_h,sys_obs_G6.B,sys_obs_G6.C,0);
y_cls_G6=lsim(sys_G4_cls,u_thermal,timespan);

figure
subplot(2,1,1)
plot(timespan,y_cls_G6(:,1))
title('Output-1 of Thermal G6')
xlabel('Time')
ylabel('\Delta P_g')
grid
subplot(2,1,2)
plot(timespan,y_cls_G6(:,2))
title('Output-2 of Thermal G6')
xlabel('Time')
ylabel('\Delta f')
sgtitle('Closed Loop Response')
grid

toc
%% Run Simulation

% Case Selection 1--> disturbance On 0---> Disturbance off
boolh=1;
boolw=1;
boolt=1; 
open 'Power_Grid_OL.slx'
sim("Power_Grid_OL.slx")
%% OUTPUT PLOTS (For Report)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Wind Power Plant Plots  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% For G2
figure
subplot(2,1,1)
plot(G2_out1.time,G2_out1.data,'LineWidth',0.1);hold on;
plot(G2_out4.time,zeros(1,length(G2_out4.time)),'--r','LineWidth',1)
grid
xlabel('Time (sec)')
ylabel('\Delta P_{g2} ')
legend('Closed Loop Output','Reference')

subplot(2,1,2)
plot(G2_out4.time,G2_out4.data,'LineWidth',0.1);hold on
plot(G2_out4.time,0.025.*ones(1,length(G2_out4.time)),'--r','LineWidth',1);hold on
plot(G2_out4.time,-0.025.*ones(1,length(G2_out4.time)),'--r','LineWidth',1);hold off
grid
xlabel('Time (sec)')
ylabel('\Delta \Theta_{p2} (rad)')
legend('Closed Loop Output','Reference')
sgtitle('Closed Loop Response of Plant: G2')


% For G5
figure
subplot(2,1,1)
plot(G5_out1.time,G5_out1.data,'LineWidth',0.1);hold on;
plot(G5_out4.time,zeros(1,length(G5_out4.time)),'--r','LineWidth',1)
grid
xlabel('Time (sec)')
ylabel('\Delta P_{G5} ')
legend('Closed Loop Output','Reference')

subplot(2,1,2)
plot(G5_out4.time,G5_out4.data,'LineWidth',0.1);hold on
plot(G5_out4.time,0.025.*ones(1,length(G5_out4.time)),'--r','LineWidth',1);hold on
plot(G5_out4.time,-0.025.*ones(1,length(G5_out4.time)),'--r','LineWidth',1);hold off
grid
xlabel('Time (sec)')
ylabel('\Delta \Theta_{p5} (rad)')
legend('Closed Loop Output','Reference')
sgtitle('Closed Loop Response of Plant: G5')


% For G8
figure
subplot(2,1,1)
plot(G8_out1.time,G8_out1.data,'LineWidth',0.1);hold on;
plot(G8_out4.time,zeros(1,length(G8_out4.time)),'--r','LineWidth',1)
grid
xlabel('Time (sec)')
ylabel('\Delta P_{p8} ')
legend('Closed Loop Output','Reference')

subplot(2,1,2)
plot(G8_out4.time,G8_out4.data,'LineWidth',0.1);hold on
plot(G8_out4.time,0.025.*ones(1,length(G8_out4.time)),'--r','LineWidth',1);hold on
plot(G8_out4.time,-0.025.*ones(1,length(G8_out4.time)),'--r','LineWidth',1);hold off
grid
xlabel('Time (sec)')
ylabel('\Delta \Theta_{G8} (rad)')
legend('Closed Loop Output','Reference')
sgtitle('Closed Loop Response of Plant: G9')


%%%% Only Theta
close all
subplot(4,1,1)

plot(G2_out4.time,G2_out4.data);hold on
plot(G2_out4.time,0.025.*ones(1,length(G2_out4.time)),'--r','LineWidth',1);hold on
plot(G2_out4.time,-0.025.*ones(1,length(G2_out4.time)),'--r','LineWidth',1);hold off
grid
axis([0 200 -0.03 0.03]);
xlabel('Time (sec)')
ylabel('\Delta \Theta_{p2} (rad)')


subplot(4,1,2)
plot(G5_out4.time,G5_out4.data);hold on
plot(G5_out4.time,0.025.*ones(1,length(G5_out4.time)),'--r','LineWidth',1);hold on
plot(G5_out4.time,-0.025.*ones(1,length(G5_out4.time)),'--r','LineWidth',1);hold off
grid
axis([0 200 -0.03 0.03]);
xlabel('Time (sec)')
ylabel('\Delta \Theta_{p5} (rad)')
legend('Closed Loop Output','Reference')



subplot(4,1,3)
plot(G8_out4.time,G8_out4.data);hold on
plot(G8_out4.time,0.025.*ones(1,length(G8_out4.time)),'--r','LineWidth',1);hold on
plot(G8_out4.time,-0.025.*ones(1,length(G8_out4.time)),'--r','LineWidth',1);hold off
grid
axis([0 200 -0.03 0.03]);
xlabel('Time (sec)')
ylabel('\Delta \Theta_{G8} (rad)')
legend('Closed Loop Output','Reference')


subplot(4,1,4)
plot(G9_out4.time,G9_out4.data);hold on
plot(G9_out4.time,0.025.*ones(1,length(G9_out4.time)),'--r','LineWidth',1);hold on
plot(G9_out4.time,-0.025.*ones(1,length(G9_out4.time)),'--r','LineWidth',1);hold off
grid
axis([0 200 -0.03 0.03]);
xlabel('Time (sec)')
ylabel('\Delta \Theta_{p9} (rad)')
legend('Closed Loop Output','Reference')
sgtitle('\Delta \Theta_{pi} for G2, G5, G8 & G9')


%%%%%%%%%%%%%%%%%%%%%%%%%%% For Thermal Power Plants %%%%%%%%%%%%%%%%%%%%%

% For G3
figure
subplot(2,1,1)
plot(G3_out1.time,G3_out1.data,'LineWidth',0.1);hold on;
plot(G3_out1.time,zeros(1,length(G3_out1.time)),'--r','LineWidth',1)
grid
xlabel('Time (sec)')
ylabel('\Delta P_{G3} ')
legend('Closed Loop Output','Reference')

subplot(2,1,2)
plot(G3_out2.time,G3_out2.data,'LineWidth',0.1);hold on
plot(G3_out2.time,10.*ones(1,length(G3_out2.time)),'--r','LineWidth',1);hold on
plot(G3_out2.time,-10.*ones(1,length(G3_out2.time)),'--r','LineWidth',1);hold off
grid
xlabel('Time (sec)')
ylabel('\Delta f_3 (Hz)')
legend('Closed Loop Output','Reference')
sgtitle('Closed Loop Response of Plant: G3')


% For G6
figure
subplot(2,1,1)
plot(G6_out1.time,G6_out1.data,'LineWidth',0.1);hold on;
plot(G6_out1.time,zeros(1,length(G6_out1.time)),'--r','LineWidth',1)
grid
xlabel('Time (sec)')
ylabel('\Delta P_{G6} ')
legend('Closed Loop Output','Reference')

subplot(2,1,2)
plot(G6_out2.time,G6_out2.data,'LineWidth',0.1);hold on
plot(G6_out2.time,10.*ones(1,length(G6_out2.time)),'--r','LineWidth',1);hold on
plot(G6_out2.time,-10.*ones(1,length(G6_out2.time)),'--r','LineWidth',1);hold off
grid
xlabel('Time (sec)')
ylabel('\Delta f_6 (Hz)')
legend('Closed Loop Output','Reference')
sgtitle('Closed Loop Response of Plant: G6')



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%For Hydro Plant%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% For G1
figure
subplot(2,1,1)
plot(G1_out1.time,G1_out1.data,'-','LineWidth',2);hold on;
plot(G1_out1.time,zeros(1,length(G1_out1.time)),'-r','LineWidth',.1)
grid
xlabel('Time (sec)')
ylabel('\Delta P_{G1} ')
legend('Closed Loop Output','Reference')
axis([0 30 10^-4*-6 10^-4*1])

subplot(2,1,2)
plot(G1_out2.time,G1_out2.data,'--','LineWidth',2);hold on
plot(G1_out2.time,zeros(1,length(G1_out2.time)),'-r','LineWidth',.1);hold off
grid
xlabel('Time (sec)')
ylabel('\Delta f_1 (Hz)')
legend('Closed Loop Output','Reference')
sgtitle('CL Response of G1 Without Disturbance Rejection')
axis([0 30 -0.01 0.06])

% For G4
figure
subplot(2,1,1)
plot(G4_out1.time,G4_out1.data,'-','LineWidth',2);hold on;
plot(G4_out1.time,zeros(1,length(G4_out1.time)),'-r','LineWidth',.1)
grid
xlabel('Time (sec)')
ylabel('\Delta P_{G4} ')
legend('Closed Loop Output','Reference')

subplot(2,1,2)
plot(G4_out2.time,G4_out2.data,'--','LineWidth',2);hold on
plot(G4_out2.time,zeros(1,length(G4_out2.time)),'-r','LineWidth',.1);hold off
grid
xlabel('Time (sec)')
ylabel('\Delta f_4 (Hz)')
legend('Closed Loop Output','Reference')
sgtitle('Closed Loop Response of Plant: G4')


% For G7
figure
subplot(2,1,1)
plot(G7_out1.time,G7_out1.data,'-','LineWidth',2);hold on;
plot(G7_out1.time,zeros(1,length(G7_out1.time)),'-r','LineWidth',1)
grid
xlabel('Time (sec)')
ylabel('\Delta P_{G7} ')
legend('Closed Loop Output','Reference')

subplot(2,1,2)
plot(G7_out2.time,G7_out2.data,'--','LineWidth',2);hold on
plot(G7_out2.time,zeros(1,length(G7_out2.time)),'-r','LineWidth',.1);hold off
grid
xlabel('Time (sec)')
ylabel('\Delta f_7 (Hz)')
legend('Closed Loop Output','Reference')
sgtitle('Closed Loop Response of Plant: G7')


%%%%%%%%%%%%%%%%%%%% Tie Line %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure
subplot(3,1,1)
plot(P_tie_sim1.time,P_tie_sim1.data)
hold on;
plot(G1_out1.time,zeros(1,length(G1_out1.time)),'-r','LineWidth',1)
grid
xlabel('time (sec)')
ylabel('\Delta P_{tie1}')



subplot(3,1,2)
plot(P_tie_sim2.time,P_tie_sim2.data)
hold on;
plot(G1_out1.time,zeros(1,length(G1_out1.time)),'-r','LineWidth',1)
grid
xlabel('time (sec)')
ylabel('\Delta P_{tie2}')



subplot(3,1,3)
plot(P_tie_sim3.time,P_tie_sim3.data)
hold on;
plot(G1_out1.time,zeros(1,length(G1_out1.time)),'-r','LineWidth',1)
grid
xlabel('time (sec)')
ylabel('\Delta P_{tie3}')
sgtitle('\Delta P_{tie} for Area #1, #2 & #3')